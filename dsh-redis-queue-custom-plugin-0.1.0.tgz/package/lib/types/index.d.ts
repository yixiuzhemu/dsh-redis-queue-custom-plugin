/**
 * dsh-redis-queue-custom-plugin: an environment-gated Redis queue consumer for
 * deepseek-harness (dsh).
 *
 * Every `pollIntervalMs` (default 15s) it samples CPU / memory / running-session
 * count; when all are within thresholds it dequeues one task from `DSH:TASK` and
 * drives it through idempotency → locked workspace provisioning → Skills-Manager
 * resolution → session launch. Redis comes from `dsh-redis-plugin`; workspace /
 * agent / skill primitives are the same host services Remote-Task uses.
 *
 * @module dsh-redis-queue-custom-plugin
 */
import type { Context } from '@deepseek-ai/cordis';
import { Config, type QueueConfig } from './config.ts';
/** Cordis function-plugin name. */
export declare const name = "redis-queue-consumer";
/**
 * Host services required before consuming. `redis` is provided by
 * dsh-redis-plugin; the rest are web-profile host services. `skillsManager`
 * (Skills-Manager) is read optionally via `ctx.get` so this plugin still loads
 * when Skills-Manager is absent.
 */
export declare const inject: string[];
export { Config };
export type { QueueConfig };
export type { TaskPayload, EnvSample, WorkspaceRef } from './types.ts';
/**
 * Wire the consumer pipeline and register every timer / subscription as a
 * reversible effect so unload and HMR roll back cleanly.
 * @param ctx - host context carrying redis + agents/llm/skills/sessions/workspaceRegistry.
 * @param config - deployment configuration (queue key, thresholds, intervals).
 */
export declare function apply(ctx: Context, config: QueueConfig): void;
