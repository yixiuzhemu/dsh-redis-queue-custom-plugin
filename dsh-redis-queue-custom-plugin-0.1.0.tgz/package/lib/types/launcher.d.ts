/**
 * Session launcher: create an agent for a task, inject its resolved skills, bind
 * it to the workspace, and deliver the first prompt. Replicates Remote-Task's
 * minimal create path (`composeCreate` + `prompt`) against the host primitives.
 *
 * @module dsh-redis-queue-custom-plugin/launcher
 */
import type { Context } from '@deepseek-ai/cordis';
import type { QueueConfig } from './config.ts';
import type { LaunchInput } from './types.ts';
export declare class SessionLauncher {
    private readonly ctx;
    private readonly cfg;
    constructor(ctx: Context, cfg: QueueConfig);
    /**
     * Create a session for the task and deliver its first prompt.
     *
     * @param input - the task, its resolved workspace, and resolved skill ids.
     * @returns the new session id (tracked by the caller for completion).
     * @throws {Error} when model resolution or agent composition fails; the caller
     *   classifies it as recoverable (requeue) or permanent (DLQ).
     */
    launch(input: LaunchInput): Promise<string>;
    /** Dispose a handle, swallowing (and logging) any error so callers stay linear. */
    private safeDispose;
    /** Attach a freshly composed session to its workspace; non-fatal on failure. */
    private attachToWorkspace;
}
