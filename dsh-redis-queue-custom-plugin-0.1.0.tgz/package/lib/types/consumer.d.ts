/**
 * Task consumer: the single orchestrator that turns one dequeued payload into a
 * launched session — dequeue → backup → validate → idempotency claim → workspace
 * (locked) → skill resolution → session launch → track — with recovery on
 * failure (requeue or dead-letter).
 *
 * @module dsh-redis-queue-custom-plugin/consumer
 */
import type { Context } from '@deepseek-ai/cordis';
import type { QueueConfig } from './config.ts';
import type { IdempotencyGuard } from './idempotency.ts';
import type { QueueStore } from './queue.ts';
import type { SkillResolver } from './skills.ts';
import type { WorkspaceProvisioner } from './workspace.ts';
import type { SessionLauncher } from './launcher.ts';
import type { ActiveSessionTracker } from './tracker.ts';
import type { ValidateResult } from './types.ts';
/** Collaborators injected into the consumer (all independently testable). */
export interface ConsumerDeps {
    readonly queue: QueueStore;
    readonly idem: IdempotencyGuard;
    readonly workspaces: WorkspaceProvisioner;
    readonly skills: SkillResolver;
    readonly launcher: SessionLauncher;
    readonly tracker: ActiveSessionTracker;
}
export declare class TaskConsumer {
    private readonly ctx;
    private readonly cfg;
    private readonly deps;
    constructor(ctx: Context, cfg: QueueConfig, deps: ConsumerDeps);
    /**
     * Consume at most one task.
     * @returns true when a task was dequeued and handled (launched, skipped as a
     *   duplicate, requeued, or dead-lettered); false when the queue was empty.
     */
    consumeOne(): Promise<boolean>;
    /**
     * Recover from a handling failure: release the idempotency claim and either
     * requeue (recoverable, under the retry cap) or dead-letter (permanent /
     * exhausted). The processing backup is always acked since the task leaves the
     * in-flight state either way.
     *
     * `raw` is the exact object that was pushed onto the processing backup list —
     * it MUST be the value passed to `ackBackup` so `lRem` matches byte-for-byte
     * under the redis plugin's `value: json` codec. `task` is the normalized form
     * used for the requeue payload (canonical field order, defaults applied).
     */
    private handleFailure;
}
/**
 * Validate a dequeued payload against the task schema. `projectId` and
 * `requestId` are mandatory; the remaining fields fall back to safe defaults so
 * a slightly-underfilled producer payload still processes (with the defaults
 * visible in the prompt).
 * @param raw - the decoded queue element.
 * @returns the normalized task, or a reason when it is a poison message.
 */
export declare function validateTask(raw: unknown): ValidateResult;
