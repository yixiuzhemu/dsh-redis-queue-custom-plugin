/**
 * Plugin configuration schema (schemastery) + a framework-agnostic
 * {@link resolveConfig} deep-merge and {@link assertConfig} invariant check.
 *
 * @module dsh-redis-queue-custom-plugin/config
 */
/** Consume strategy: non-blocking pop per tick, or a short blocking pop. */
export type ConsumeMode = 'poll' | 'blocking';
/** Idempotency key/TTL settings. */
export interface IdempotencyConfig {
    /** Prefix for the `SET NX` claim key (`{prefix}:{requestId}`). */
    keyPrefix: string;
    /** TTL of the in-flight `processing` claim (short; auto-releases on crash). */
    processingTtlMs: number;
    /** TTL of the terminal `done` claim (long; guards against replay). */
    doneTtlMs: number;
}
/** Distributed-lock settings for workspace provisioning. */
export interface LockConfig {
    /** Prefix for the workspace lock key (`{prefix}:{projectId}`). */
    keyPrefix: string;
    /** Lock TTL; the redis plugin's watchdog renews it during the critical section. */
    ttlMs: number;
    /** Max acquisition retries when the lock is contended. */
    retryCount: number;
    /** Interval between acquisition retries. */
    retryIntervalMs: number;
    /** TTL of the projectId→workspaceId cache (lock-free fast path). */
    wsCacheTtlMs: number;
}
/** Environment admission thresholds. */
export interface ThresholdConfig {
    /** Max CPU utilization ratio (0..1) allowed to consume. */
    maxCpuUsageRatio: number;
    /** Max system memory utilization ratio (0..1) allowed to consume. */
    maxMemoryUsageRatio: number;
    /** Max in-flight sessions launched by this plugin. */
    maxConcurrentSessions: number;
    /** CPU sampling window; shorter is more reactive but noisier. */
    cpuSampleWindowMs: number;
}
/** Resolved plugin configuration. */
export interface QueueConfig {
    /** Master switch; false disables the consumer entirely. */
    enabled: boolean;
    /** Queue key to consume. */
    queueKey: string;
    /** Dead-letter list key for poison/unrecoverable messages. */
    deadLetterKey: string;
    /** Processing-backup list key for crash recovery. */
    processingKey: string;
    /** Scheduler poll interval. */
    pollIntervalMs: number;
    /** Non-blocking pop vs short blocking pop. */
    consumeMode: ConsumeMode;
    /** Blocking pop timeout (consumeMode=blocking). */
    blockingTimeoutSec: number;
    /** true: lPop (pairs with an rPush producer) for FIFO. */
    fifo: boolean;
    /** Max tasks consumed per tick. */
    batchSize: number;
    /** Base directory workspaces are created under; empty → ~/.dsh/redis-queue/workspaces. */
    workspaceRoot: string;
    /** Default LLM provider when the task does not route a model. */
    defaultProvider: string;
    /** Default model name. */
    defaultModel: string;
    /** Optional prompt template override (supports {field} placeholders). */
    promptTemplate: string;
    /** Re-queue a recoverable failure instead of dropping it. */
    requeueOnFailure: boolean;
    /** Max requeue attempts before the task is sent to the DLQ. */
    maxRetries: number;
    /**
     * Upper bound on how long a tracked session may stay in-flight before the
     * tracker stops counting it toward the concurrency gate. Guards against a
     * lost `turn/end` / `agent/error` event permanently wedging the gate.
     * The idempotency claim and processing backup are deliberately NOT touched
     * by the sweep (the session may still complete elsewhere); the claim's own
     * `processingTtlMs` bounds the duplicate-execution window.
     */
    sessionMaxLifetimeMs: number;
    /** How often the tracker sweeps for stuck sessions. */
    sessionSweepIntervalMs: number;
    idempotency: IdempotencyConfig;
    lock: LockConfig;
    thresholds: ThresholdConfig;
}
/** Deep defaults so a bare `- name: dsh-redis-queue-custom-plugin` line works. */
export declare const defaultConfig: QueueConfig;
export type DeepPartial<T> = {
    [K in keyof T]?: T[K] extends object ? DeepPartial<T[K]> : T[K];
};
/**
 * Merge a partial (possibly deeply nested) user config over {@link defaultConfig}.
 * `undefined` values are ignored so `cordis.patch.yml` layers compose.
 */
export declare function resolveConfig(input?: DeepPartial<QueueConfig>): QueueConfig;
/**
 * Validate config invariants Schemastery cannot express.
 * @param config - resolved configuration.
 * @throws {Error} when a numeric bound or key is invalid.
 */
export declare function assertConfig(config: QueueConfig): void;
/**
 * Deployment-time schema (schemastery). Loaded by the Cordis loader to validate
 * the `config:` block of this plugin's line in `cordis.patch.yml`.
 */
export declare const Config: import("@deepseek-ai/schemastery").Schema;
