/**
 * Active-session tracker: counts in-flight sessions (the environment gate's
 * "running sessions" metric) and settles them on completion or error.
 *
 * Settlement drives the idempotency state machine and the processing backup:
 * a completed first turn marks the claim `done` and acks the backup; an error
 * releases the claim and requeues (or dead-letters) the task.
 *
 * @module dsh-redis-queue-custom-plugin/tracker
 */
import type { Context } from '@deepseek-ai/cordis';
import type { QueueConfig } from './config.ts';
import type { IdempotencyGuard } from './idempotency.ts';
import type { QueueStore } from './queue.ts';
import type { TrackedMeta } from './types.ts';
export declare class ActiveSessionTracker {
    private readonly ctx;
    private readonly cfg;
    private readonly idem;
    private readonly queue;
    private readonly active;
    private sweepTimer;
    constructor(ctx: Context, cfg: QueueConfig, idem: IdempotencyGuard, queue: QueueStore);
    /**
     * Subscribe to host completion/error events and start the stuck-session
     * sweeper. Registered via `ctx.effect`, so the returned disposer
     * unsubscribes, stops the sweeper, and drops any still-tracked sessions
     * (their idempotency claims age out via `processingTtlMs`; the host owns
     * their lifecycle after unload).
     */
    start(): () => void;
    /** Number of sessions launched and not yet settled (the concurrency gate). */
    running(): number;
    /** Begin tracking a launched session so it counts toward the gate. */
    track(sessionId: string, meta: TrackedMeta): void;
    /**
     * Drop sessions that have been in-flight longer than `sessionMaxLifetimeMs`.
     * Only the concurrency slot is released — the idempotency claim and the
     * processing backup are left untouched so a late `turn/end` cannot cause a
     * duplicate execution if the same requestId is redelivered.
     */
    private sweep;
    /**
     * Settle a tracked session exactly once, releasing the concurrency slot and
     * finalizing idempotency + backup. Unknown ids are ignored (not ours).
     * @param sessionId - the session that completed or errored.
     * @param outcome - `done` (first turn ended) or `error` (agent error).
     * @param error - the original error when outcome is `error`.
     */
    private settle;
}
