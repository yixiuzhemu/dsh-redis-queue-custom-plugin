/**
 * Workspace provisioning: ensure a `projectId` maps to a host workspace,
 * creating it under a Redis distributed lock so concurrent consumers (across
 * instances) never race to create the same directory.
 *
 * Backed by the host `workspaceRegistry` service (the same primitive Remote-Task
 * uses). `registry.create` is idempotent by canonical path, and the lock is
 * released by `ctx.redis.lock.withLock` in its own `finally` (watchdog-renewed
 * during the critical section), so the lock is always freed after creation.
 *
 * @module dsh-redis-queue-custom-plugin/workspace
 */
import type { Context } from '@deepseek-ai/cordis';
import type { QueueConfig } from './config.ts';
import type { WorkspaceRef } from './types.ts';
export declare class WorkspaceProvisioner {
    private readonly ctx;
    private readonly cfg;
    constructor(ctx: Context, cfg: QueueConfig);
    private registry;
    private root;
    private cacheKey;
    /**
     * Ensure the workspace for `projectId` exists and return its id + path.
     *
     * Fast path: a cached projectId→workspaceId mapping that the registry still
     * knows is reused without taking the lock. Slow path: acquire the distributed
     * lock, double-check existence, create when missing, then refresh the cache.
     *
     * @param projectId - the task's workspace id (also the lock key + dir name).
     * @param title - optional workspace display title (defaults to projectId).
     * @returns the created or reused workspace reference.
     * @throws {Error} when the lock cannot be acquired or the directory is invalid
     *   (the consumer classifies these as recoverable vs. permanent).
     */
    ensure(projectId: string, title?: string): Promise<WorkspaceRef>;
    /** Find a registered workspace whose canonical path equals `target`. */
    private findByPath;
}
