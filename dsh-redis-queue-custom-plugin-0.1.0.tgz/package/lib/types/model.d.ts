/**
 * Model route resolution against `ctx.llm`, mirroring Remote-Task's `model.ts`.
 *
 * @module dsh-redis-queue-custom-plugin/model
 */
import type { Context } from '@deepseek-ai/cordis';
/** Optional per-task model override; absent falls back to deployment defaults. */
export interface ModelRequest {
    readonly provider?: string;
    readonly model?: string;
    readonly reasoningEffort?: string;
    readonly maxTokens?: number;
}
/** A resolved, validated model route plus per-session generation limits. */
export interface ResolvedModel {
    readonly provider: string;
    readonly model: string;
    readonly reasoningEffort?: unknown;
    readonly maxTokens?: number;
}
/**
 * Resolve and validate a model route from an optional override or the
 * deployment defaults, using `ctx.llm.resolveCallConfig` to verify the
 * provider/model pair is registered and to carry generation limits through.
 *
 * @param ctx - plugin context with the llm service.
 * @param req - optional per-task model override.
 * @param defaultProvider - deployment default provider.
 * @param defaultModel - deployment default model.
 * @returns the resolved model route.
 * @throws {Error} when the provider/model pair is not registered.
 */
export declare function resolveModelSelection(ctx: Context, req: ModelRequest | undefined, defaultProvider: string, defaultModel: string): Promise<ResolvedModel>;
/** Project a resolved model into the `agentOptions` shape `ctx.agents.create` expects. */
export declare function agentOptionsOf(resolved: ResolvedModel): Record<string, unknown>;
