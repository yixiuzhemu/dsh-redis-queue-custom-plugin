/**
 * Scheduler: a reversible interval timer (default 15s) that samples the
 * environment and, when it is within thresholds, drives the consumer.
 *
 * A re-entrancy flag guarantees an overlapping tick never runs while a previous
 * one is still in flight (a slow workspace-lock acquisition, for example), so
 * tasks are never dequeued faster than they are handled.
 *
 * @module dsh-redis-queue-custom-plugin/scheduler
 */
import type { Context } from '@deepseek-ai/cordis';
import type { QueueConfig } from './config.ts';
import type { EnvironmentMonitor } from './monitor.ts';
import type { TaskConsumer } from './consumer.ts';
export declare class Scheduler {
    private readonly ctx;
    private readonly cfg;
    private readonly monitor;
    private readonly consumer;
    private timer;
    private ticking;
    constructor(ctx: Context, cfg: QueueConfig, monitor: EnvironmentMonitor, consumer: TaskConsumer);
    /**
     * Start the poll timer. Registered via `ctx.effect`; the returned disposer
     * stops it on unload/HMR. `unref()` keeps the timer from holding the process
     * open when the host is otherwise idle.
     */
    start(): () => void;
    /** Stop the poll timer (idempotent). */
    stop(): void;
    /** One poll: gate on the environment, then consume up to `batchSize` tasks. */
    private tick;
}
