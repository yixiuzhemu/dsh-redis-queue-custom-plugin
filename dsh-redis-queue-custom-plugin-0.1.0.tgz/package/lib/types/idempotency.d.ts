/**
 * Idempotency guard: an atomic `SET NX` claim keyed by `requestId` so one task
 * executes at most once across restarts, retries, and multiple consumers.
 *
 * State machine: `processing` (short TTL, auto-releases on crash) → `done:{id}`
 * (long TTL, guards against replay). A recoverable failure releases the claim so
 * a requeued task can re-acquire it.
 *
 * @module dsh-redis-queue-custom-plugin/idempotency
 */
import type { Context } from '@deepseek-ai/cordis';
import type { QueueConfig } from './config.ts';
/** Outcome of a claim attempt. */
export type ClaimResult = {
    readonly state: 'acquired';
} | {
    readonly state: 'duplicate';
    readonly status: string;
};
export declare class IdempotencyGuard {
    private readonly ctx;
    private readonly cfg;
    constructor(ctx: Context, cfg: QueueConfig);
    private key;
    /**
     * Atomically claim a requestId. Success means this is the first live attempt;
     * a duplicate means it is already processing or already done.
     * @param requestId - the task's session id.
     * @returns the claim outcome (with the existing status when duplicated).
     */
    claim(requestId: string): Promise<ClaimResult>;
    /**
     * Mark a claim as successfully completed, extending its TTL so a late replay
     * of the same requestId is still recognized as done.
     * @param requestId - the task's session id.
     * @param sessionId - the launched session, recorded for traceability.
     */
    markDone(requestId: string, sessionId: string): Promise<void>;
    /**
     * Release an in-flight claim so a requeued task can be retried. Only used on
     * recoverable failures; a done claim is never released.
     * @param requestId - the task's session id.
     */
    release(requestId: string): Promise<void>;
}
