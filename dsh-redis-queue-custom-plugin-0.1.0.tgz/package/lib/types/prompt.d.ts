/**
 * First-turn prompt construction from a task payload.
 *
 * @module dsh-redis-queue-custom-plugin/prompt
 */
import type { TaskPayload } from './types.ts';
/**
 * Build the opening prompt for a task. When `template` is supplied it is used
 * verbatim with `{field}` placeholders substituted from the task; otherwise a
 * sensible translation-task default is emitted.
 *
 * @param task - the dequeued task payload.
 * @param template - optional deployment-provided template override.
 * @returns the prompt text delivered as the session's first user message.
 */
export declare function buildPrompt(task: TaskPayload, template?: string): string;
