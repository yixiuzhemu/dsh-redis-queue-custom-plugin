/**
 * Environment monitor: samples CPU, system memory, and the running-session count
 * and decides whether the consumer may take another task.
 *
 * CPU utilization is derived from `os.cpus()` idle/total deltas (reliable across
 * platforms; `os.loadavg()` is not meaningful on Windows). A baseline snapshot is
 * taken on start and refreshed each sample, so the ratio reflects the window
 * between two reads.
 *
 * @module dsh-redis-queue-custom-plugin/monitor
 */
import type { Context } from '@deepseek-ai/cordis';
import type { QueueConfig } from './config.ts';
import type { EnvSample } from './types.ts';
import type { ActiveSessionTracker } from './tracker.ts';
export declare class EnvironmentMonitor {
    private readonly ctx;
    private readonly cfg;
    private readonly tracker;
    private prev;
    private timer;
    constructor(ctx: Context, cfg: QueueConfig, tracker: ActiveSessionTracker);
    /**
     * Establish the CPU delta baseline and start a periodic refresher driven by
     * `thresholds.cpuSampleWindowMs`. `sample()` is a pure read against `prev`,
     * so the sampling window is stable regardless of how often the scheduler
     * calls it (multiple times per tick, or ticks skipped by the gate).
     *
     * Registered via `ctx.effect`; the returned disposer stops the timer.
     */
    start(): () => void;
    /** Sum idle and total jiffies across every core. */
    private snapshotCpu;
    /**
     * CPU utilization between the last periodic snapshot and now. Pure read —
     * does NOT advance `prev` (the sampling-window timer owns that), so repeated
     * calls within one window return the same value.
     */
    private computeCpu;
    /**
     * Take one environment sample and decide admission.
     * @returns the metrics plus whether consuming is allowed (and why not).
     */
    sample(): EnvSample;
}
