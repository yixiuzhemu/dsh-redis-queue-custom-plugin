/**
 * Redis queue operations: dequeue, processing-backup, ack, requeue, and
 * dead-letter. Encapsulated so both the consumer and the tracker share one
 * consistent encoding path (a value we push is byte-identical to one we lRem).
 *
 * @module dsh-redis-queue-custom-plugin/queue
 */
import type { Context } from '@deepseek-ai/cordis';
import type { QueueConfig } from './config.ts';
import type { TaskPayload } from './types.ts';
/** A DLQ envelope wrapping a poison/failed task with its failure context. */
export interface DeadLetterEnvelope {
    readonly task: TaskPayload;
    readonly reason: string;
    readonly at: string;
}
export declare class QueueStore {
    private readonly ctx;
    private readonly cfg;
    constructor(ctx: Context, cfg: QueueConfig);
    /**
     * Dequeue one task, honoring the configured mode/direction.
     * @returns the decoded payload, or null when the queue is empty (or a blocking
     *   pop timed out).
     */
    pop(): Promise<TaskPayload | null>;
    /** Current queue depth (diagnostics / optional pre-check). */
    len(): Promise<number>;
    /** Push a popped task onto the processing-backup list (crash recovery). */
    backup(task: TaskPayload): Promise<void>;
    /** Remove one matching task from the processing-backup list (ack). */
    ackBackup(task: TaskPayload): Promise<void>;
    /**
     * Re-queue a task for another attempt, bumping its internal retry counter.
     * Pushed to the head (lPush) so a retry is picked up before newer work.
     * @param task - the task to requeue.
     * @param retries - the retry count to stamp (already incremented by caller).
     */
    requeue(task: TaskPayload, retries: number): Promise<void>;
    /** Send a task to the dead-letter list with its failure context. */
    toDlq(task: TaskPayload, reason: string): Promise<void>;
}
